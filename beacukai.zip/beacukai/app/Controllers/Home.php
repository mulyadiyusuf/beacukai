<?php

namespace App\Controllers;

class Home extends BaseController
{
    public function index()
    {
        $data['title'] = 'Direktorat Jenderal Bea Dan Cukai';
        echo view('home/index',$data);
    }

    public function default()
    {
        return view('welcome_message');
    }
}
