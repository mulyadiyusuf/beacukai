<?= $this->extend('template/template'); ?>
<?= $this->section('content'); ?>
<div class="section">

<nav class="navbar fixed-top navbar-expand-lg navbar-dark background p-4">
<div class="container-fluid header">
  <img  width="50" height="50" src="<?= base_url('vendor/img/beacukai.png') ?>" alt="">
  <a class="navbar-brand ms-3 brand text-warning" href="#"> Bea Cukai</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasRight" aria-controls="offcanvasRight">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse " id="navbarNav">
      <ul class="navbar-nav ms-auto side mt-2">
      <li class="nav-item dropdown profile mx-2">
          <a class="bs-gray nav-link dropdown-toggle" href="#aa" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Profile
          </a>
          <ul class="dropdown-menu" id="dropdown">
           
            <li><a class="dropdown-item " href="#">Sekilas DCJB</a></li>
            <li><a class="dropdown-item " href="#">Tugas dan Fungsi</a></li>
            <li><a class="dropdown-item " href="#">Visi Misi & Strategi</a></li>
            <li><a class="dropdown-item " href="#">Logo DJBC</a></li>
            <li><a class="dropdown-item " href="#">Mars DJCB</a></li>
            <li><a class="dropdown-item " href="#">Kode Etik & Perilaku Pegawai</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a href="#" class="dropdown-item">Struktur Organisasi</a></li>
            <li><a href="#" class="dropdown-item">Video Profile DJCB</a></li>
            <li><a href="#" class="dropdown-item">Sejarah DJCB</a></li>
            <li><a href="#" class="dropdown-item">Kantor Bea & Cukai</a></li>
            
          </ul>
        </li>
        <li class="nav-item dropdown mx-2">
          <a class="bs-gray nav-link dropdown-toggle" href="#"  role="button" data-bs-toggle="dropdown" aria-expanded="false">Pabean</a>
          <ul class="dropdown-menu" id="dropdown">
           
           <li><a class="dropdown-item " href="#">Impor</a></li>
           <li><a class="dropdown-item " href="#">Expor</a></li>
           <li><a class="dropdown-item " href="#">AEO</a></li>
           <li><a class="dropdown-item " href="#">FTA</a></li>
         
           
         </ul>
        </li>  
        <li class="nav-item dropdown mx-2">
        <a class="bs-gray nav-link dropdown-toggle" href="#"  role="button" data-bs-toggle="dropdown" aria-expanded="false">Fasilitas</a>
        <ul class="dropdown-menu" id="dropdown">
           
           <li><a class="dropdown-item " href="#">Pembebasan Bea Masuk</a></li>
           <li><a class="dropdown-item " href="#">Pertambangan</a></li>
           <li><a class="dropdown-item " href="#">TPB</a></li>
           <li><a class="dropdown-item " href="#">KITE</a></li>
         
           
         </ul>
        </li>
        <li class="nav-item dropdown mx-2">
        <a class="bs-gray nav-link dropdown-toggle" href="#"  role="button" data-bs-toggle="dropdown" aria-expanded="false">Layanan Informasi</a>
        <ul class="dropdown-menu" id="dropdown">
           
           <li><a class="dropdown-item " href="#">Layanan Utama</a></li>
           <li><a class="dropdown-item " href="#">Profile</a></li>
           <li><a class="dropdown-item " href="#">Regulasi</a></li>
           <li><a class="dropdown-item " href="#">Daftar Informasi Publik</a></li>
           <li><hr class="dropdown-divider"></li>
           <li><a class="dropdown-item " href="#"> Informasi Secara Berkala</a></li>
           <li><a class="dropdown-item " href="#">Informasi Wajib Serta Merta</a></li>
           <li><a class="dropdown-item " href="#"> Informasi Yang Wajib Tersedia</a></li>
         </ul>
        </li>
        <li class="nav-item dropdown mx-2">
        <a class="bs-gray nav-link dropdown-toggle" href="#"  role="button" data-bs-toggle="dropdown" aria-expanded="false">Lainnya</a>
        <ul class="dropdown-menu" id="dropdown">
           
           <li><a class="dropdown-item " href="#">Cukai</a></li>
           <li><a class="dropdown-item " href="#">Layanan</a></li> 
           <li><a class="dropdown-item " href="#">FAQ</a></li>
           <li><a class="dropdown-item " href="#">STATISTIK</a></li>
         
           
         </ul>
        </li>
        
        
      </ul>                                       
      
    </div>
    </div>
</nav>

</div>
<div class="container-fluid background centre">
  <div class="row text-">
    <div class="col-sm-7 col-md-7">
      <h2 class="bs-gray">Direktorat Jenderal</h2>
      <h1 class="header-title text-warning text-title">Bea dan Cukai</h1>
      <p class="bs-gray">Membuat perumusan dan pelaksanaan kebijakan</p>
      <button class="button btn btn-primaryy">SELENGKAPNYA</button>
    </div>
    <div class="col-sm-5 col-md-5 none">
      <img src="<?= base_url('vendor/img/image.jpg') ?>" alt="" class="mt-minus">
    </div>
  </div>
</div>
<div class="container-fluid bg-light pt-10 pb-10 centre-2">
<h2 class="h2 text-center">Tentang Kami</h2>
  <div class="row mt-5">
  
    <div class="col-sm-6 col-md-6">
      <img src="<?= base_url('vendor/img/lima.jpg') ?>" alt="" class="shadows img-thumbnail">
    </div>
    <div class="col-sm-6 col-md-6">
      <h1>Membuat Peraturan Cukai</h1>
      <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Voluptas ex quasi nemo perspiciatis, est inventore alias repudiandae vel doloremque odio laudantium minus voluptates, quo veritatis minima natus modi quisquam. Sint!</p>
    </div>
  </div>
</div>

<div class="container-fluid bg-light pt-10 pb-10 centre-2">
<h2 class="h2 text-center">Produk Digital</h2>
<p class="text-center text-secondary">Berikut ini daftar Sistem Aplikasi yang kami sediakan

<br class="br">  untuk layanan yang dapat diakses</p>
  <div class="row mt-5 text-center mb-5">
  
    <div class="col-sm-4 col-md-4">
    <i class="fa calc fa-house-user fs- mt-4 mb-4 kuning background p-3 rounded-circle"></i>
    <h4>Kanal Bea Cukai</h4>
    </div>
    <div class="col-sm-4 col-md-4">
    <i class="fa calc fa-passport fs- mt-4 mb-4 kuning background p-3 rounded-circle"></i>
    <h4>Ceisa Mobile</h4>
    </div>
    <div class="col-sm-4 col-md-4">
    <i class="fas calc fa-book fs- mt-4 mb-4 kuning background p-3 rounded-circle"></i>
    <h4>Warta Bea Cukai</h4>

    </div>
  </div>
  <div class="row text-center">
  
    <div class="col-sm-4 col-md-4">
    <i class=" calc fas fa-search-location  fs- mt-4 mb-4 kuning background p-3 rounded-circle"></i>
    <h4>UU Pabean</h4>

    </div>
    <div class="col-sm-4 col-md-4">
    <i class="fas calc fa-volume-up fs- mt-4 mb-4 kuning background p-3 rounded-circle"></i>
    <h4>Ceisa Mobile</h4>

    </div>
    <div class="col-sm-4 col-md-4">
    <i class="fas calc fa-file fs- mt-4 mb-4 kuning background p-3 rounded-circle"></i>
    <h4>Bravo Bea Cukai</h4>

    </div>
  </div>
</div>

<div class="container-fluid pt-5 pb-5">
  <h2 class="h2 text-center">Kontak Pusat</h2>
  <p class="text-center text-secondary">Anda dapat menghubungi bea cukai melalui<br class="br">  info yang ada  dibawah ini. </p>
  <div class="row rows unset paddings text-center text-start mt-5 margin-3 mb-3">
    <div class="col-lg-4 mb-4 ">
      <div class="card radius-none shadows">
        <i class="fa calc fa-map-marker-alt fs- mt-4 mb-4 color-primary iconn"></i>
        <h3 class="h3  ">Lokasi</h3>
        <p class="text-secondary mt-2 p-11 cc">Jl.Jenderal A Yani (By Pass) Rawamangun, Jakarta Timur - 13230</p>
      </div></div>
    <div class="col-lg-4 mb-4">
      <div class="card radius-none shadows"><i class="fa fa-phone calc mt-4 mb-4 color-primary iconn"></i>
        <h3 class="h3 secondary">Telepon</h3>
        <p class="text-secondary mt-2 p-11 cc">1500225  <br>202045</p></div></div>
    <div class="col-lg-4 mb-4">
      <div class="card radius-none shadows"><i class="fa fa-envelope calc mt-4 mb-4 color-primary iconn"></i>
        <h3 class="h3 secondary">Email</h3>
        <p class="text-secondary mt-2 p-11 cc">pengaduan.beacukai@customs.go.id <br> anothergmail@gmail.com</p></div></div>
  </div>
  <div class="row justify-content-center rows unset paddings text-center margin-up">
    <div class="col-lg-5">
      <div class="form-group mb-4">
        <input type="text" class="form-control font-20" placeholder="Nama Lengkap">
      </div>
      <div class="form-group mb-4">
        <input type="text" class="form-control font-20" placeholder="Alamat Email">
      </div>
      <div class="form-group mb-3">
        <textarea name="" id="" cols="30" rows="7" class="form-control font-20" placeholder="Pesan Anda"></textarea>
      </div>
      <div class="d-flex keren mb-4">
      <button class="btn btn-tryy background text-center radius-50 text-white ww-50 btn-block">KIRIM PESAN</button>
    </div>
  </div>
    <div class="col-lg-7">
      <div class="contact-map mt-60">
        <div class="gmap_canvas">                            
            <iframe height="410" class=" w-100" id="gmap_canvas" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3966.4340616188183!2d106.87331531436044!3d-6.2063350625223315!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69f48566a071ef%3A0x600f3ad15637ed13!2sDirektorat%20Jenderal%20Bea%20dan%20Cukai!5e0!3m2!1sid!2sid!4v1664286159521!5m2!1sid!2sid" frameborder="0" scrolling="no" marginheight="" marginwidth="0"></iframe>
        </div>
    </div> <!-- contact map -->
    </div>
   
  </div>
</div>
<?= $this->endSection(); ?>