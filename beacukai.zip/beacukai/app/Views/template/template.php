<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="apple-touch-icon" sizes="57x57" href="<?= base_url('vendor/img') ?>/apple-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="<?= base_url('vendor/img') ?>/apple-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="<?= base_url('vendor/img') ?>/apple-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="<?= base_url('vendor/img') ?>/apple-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="<?= base_url('vendor/img') ?>/apple-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="<?= base_url('vendor/img') ?>/apple-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="<?= base_url('vendor/img') ?>/apple-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="<?= base_url('vendor/img') ?>/apple-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="<?= base_url('vendor/img') ?>/apple-icon-180x180.png">
<link rel="icon" type="image/png" sizes="192x192"  href="<?= base_url('vendor/img') ?>/android-icon-192x192.png">
<link rel="icon" type="image/png" sizes="32x32" href="<?= base_url('vendor/img') ?>/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="96x96" href="<?= base_url('vendor/img') ?>/favicon-96x96.png">
<link rel="icon" type="image/png" sizes="16x16" href="<?= base_url('vendor/img') ?>/favicon-16x16.png">
<link rel="manifest" href="/manifest.json">
<meta name="msapplication-TileColor" content="#ffffff">
<meta name="msapplication-TileImage" content="/ms-icon-144x144.png">
<meta name="theme-color" content="#ffffff">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css" integrity="sha384-DyZ88mC6Up2uqS4h/KRgHuoeGwBcD4Ng9SiP4dIRy0EXTlnuz47vAwmeGwVChigm" crossorigin="anonymous"/>
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/fontawesome.css" integrity="sha384-DyZ88mC6Up2uqS4h/KRgHuoeGwBcD4Ng9SiP4dIRy0EXTlnuz47vAwmeGwVChigm" crossorigin="anonymous"/>     
<link href="<?= base_url('vendor/css/bootstrap.min.css') ?>" rel="stylesheet">
<link rel="stylesheet" href="<?= base_url('vendor/style.css') ?>">
    <title><?= $title; ?></title>
</head>
<body>
<?= $this->renderSection('content') ?>
<div class="container-fluid footer background centre-2">
    <div class="row pt-5">
        <div class="col-sm-4">
      <h3 class="text-white mb-4">Bea Cukai</h3>
      <p class="bs-gray mb-5">Lorem ipsum, dolor sit amet consectetur adipisicing elit. Est aperiam autem veniam soluta quas ducimus sed odio nulla aliquid neque? Quos amet hic obcaecati. Aliquam reprehenderit  cumque obcaecati explicabo!</p>

        </div>
        <div class="col-sm-3 mb-4">
            <h3 class="text-white mb-3">Produk</h3>
           
            <a href="#" class="bs-gray link">Kanal Bea Cukai</a>
            <a href="#" class="bs-gray link">Ceisa Mobile</a>
            <a href="#" class="bs-gray link">Warta Bea Cukai</a>
            <a href="#" class="bs-gray link mb-3">UU Pabean</a>
          
        </div>
        <div class="col-sm-3 mb-4"><h3 class="text-white mb-3">Perusahaan</h3>
        <a href="#" class="bs-gray link">Live Chat</a>
            <a href="#" class="bs-gray link">Customer</a>
            <a href="#" class="bs-gray link">Kebijakan Privasi</a>
            <a href="#" class="bs-gray link mb-3">Syarat Ketentuan</a>
      </div>
        <div class="col-sm-2 mb-4"><h3 class="text-white mb-3">Bantuan</h3>
        <a href="#" class="bs-gray link">Live Chat</a>
            <a href="#" class="bs-gray link">Customer</a>
            <a href="#" class="bs-gray link">Kebijakan Privasi</a>
            <a href="#" class="bs-gray link">Syarat Ketentuan</a>
         
    </div>
    </div>
</div>
 
<div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasRight" aria-labelledby="offcanvasRightLabel">
  <div class="offcanvas-header">
    <h5 class="offcanvas-title" id="offcanvasRightLabel">Offcanvas right</h5>
    <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
  </div>
  <div class="offcanvas-body">
    ...
  </div>
</div>
<footer class="bg-primaryy p-4 fs-5 text-center text-white">Copyright &copy; <?= date('Y') ?> Mulyadi Yusuf</footer>
<script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk=" crossorigin="anonymous"></script>
<script src="asset/vendor/jquery-easing/jquery.easing.min.js"></script>
<script>

</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
<script>
    $(function() {
        $('.link').addClass('d-block mb-4')
   
    })
</script>
</body>
</html>